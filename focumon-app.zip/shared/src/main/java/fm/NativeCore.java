package fm;
import java.io.*; import java.net.*; import java.nio.charset.StandardCharsets; import java.nio.file.Files; import java.util.*;
/** Общая нативная часть: хранилище, LAN-мультиплеер (TCP+UDP-поиск), WebDAV, блокировка. Вызывается из JS. */
public class NativeCore {
  public interface Js { void run(String script); }
  public interface Lock { void set(boolean on); }
  static final int PORT = 47777;
  final Js js; final Lock lk; final File dir;
  final PrintWriter[] slots = new PrintWriter[3];
  volatile PrintWriter up; volatile boolean hosting;
  ServerSocket srv; DatagramSocket disc; Socket cs;
  public NativeCore(File dir, Js js, Lock lk) { this.dir = dir; this.js = js; this.lk = lk; dir.mkdirs(); }
  static String q(String s) { StringBuilder b = new StringBuilder("\"");
    for (char c : s.toCharArray()) switch (c) { case '\\': b.append("\\\\"); break; case '"': b.append("\\\""); break;
      case '\n': b.append("\\n"); break; case '\r': b.append("\\r"); break; case '\u2028': b.append("\\u2028"); break; case '\u2029': b.append("\\u2029"); break; default: b.append(c); }
    return b.append('"').toString(); }
  public void emit(String e, String d) { js.run("window.onNative&&window.onNative(" + q(e) + "," + q(d) + ")"); }
  File f(String k) { return new File(dir, k.replaceAll("\\W", "_")); }
  public String kvGet(String k) { try { return new String(Files.readAllBytes(f(k).toPath()), StandardCharsets.UTF_8); } catch (IOException e) { return ""; } }
  public void kvSet(String k, String v) { try { Files.write(f(k).toPath(), v.getBytes(StandardCharsets.UTF_8)); } catch (IOException e) { emit("err", "Запись: " + e.getMessage()); } }
  public void lock(boolean on) { lk.set(on); }
  static PrintWriter wr(Socket s) throws IOException { return new PrintWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8), true); }
  static BufferedReader rd(Socket s) throws IOException { return new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8)); }
  synchronized int free() { for (int i = 0; i < slots.length; i++) if (slots[i] == null) return i; return -1; }
  public void host(String name) { close(); hosting = true;
    new Thread(() -> { try { srv = new ServerSocket(PORT);
        while (hosting) { Socket s = srv.accept(); int i = free(); if (i < 0) { s.close(); continue; } accept(s, i); }
      } catch (IOException e) { if (hosting) emit("err", "Хост: " + e.getMessage()); } }).start();
    new Thread(() -> { try { disc = new DatagramSocket(null); disc.setReuseAddress(true); disc.bind(new InetSocketAddress(PORT)); byte[] b = new byte[64];
        while (hosting) { DatagramPacket p = new DatagramPacket(b, b.length); disc.receive(p);
          if (new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8).equals("FM?")) { byte[] r = ("FM!" + name).getBytes(StandardCharsets.UTF_8);
            disc.send(new DatagramPacket(r, r.length, p.getAddress(), p.getPort())); } }
      } catch (IOException e) { } }).start();
    emit("hosting", ips()); }
  void accept(Socket s, int i) throws IOException { slots[i] = wr(s); emit("join", "" + (i + 1)); BufferedReader r = rd(s);
    new Thread(() -> { try { String l; while ((l = r.readLine()) != null) emit("net", (i + 1) + "|" + l); } catch (IOException e) { }
      slots[i] = null; emit("leave", "" + (i + 1)); }).start(); }
  public void join(String ip) { close();
    new Thread(() -> { try { cs = new Socket(); cs.connect(new InetSocketAddress(ip.trim(), PORT), 4000); up = wr(cs); emit("joined", "");
        BufferedReader r = rd(cs); String l; while ((l = r.readLine()) != null) emit("net", l);
      } catch (IOException e) { emit("err", "Подключение: " + e.getMessage()); } emit("down", ""); }).start(); }
  public void discover() { new Thread(() -> { StringBuilder sb = new StringBuilder();
      try (DatagramSocket d = new DatagramSocket()) { d.setBroadcast(true); d.setSoTimeout(1500); byte[] m = "FM?".getBytes();
        d.send(new DatagramPacket(m, m.length, InetAddress.getByName("255.255.255.255"), PORT)); byte[] b = new byte[64];
        while (true) { DatagramPacket p = new DatagramPacket(b, b.length); d.receive(p); String s = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
          if (s.startsWith("FM!")) sb.append(p.getAddress().getHostAddress()).append('|').append(s.substring(3)).append(';'); }
      } catch (IOException e) { } emit("found", sb.toString()); }).start(); }
  public void send(String l) { PrintWriter w = up; if (w != null) synchronized (w) { w.println(l); } }
  public void sendTo(int i, String l) { PrintWriter w = slots[i - 1]; if (w != null) synchronized (w) { w.println(l); } }
  public void sendAll(String l) { for (int i = 1; i <= slots.length; i++) sendTo(i, l); }
  public void close() { hosting = false;
    try { if (srv != null) srv.close(); if (disc != null) disc.close(); if (cs != null) cs.close(); } catch (IOException e) { }
    Arrays.fill(slots, null); up = null; }
  String ips() { StringBuilder sb = new StringBuilder();
    try { for (NetworkInterface n : Collections.list(NetworkInterface.getNetworkInterfaces())) for (InetAddress a : Collections.list(n.getInetAddresses()))
        if (a instanceof Inet4Address && !a.isLoopbackAddress()) sb.append(sb.length() > 0 ? ", " : "").append(a.getHostAddress()); } catch (IOException e) { }
    return sb.toString(); }
  /** WebDAV: GET/PUT одного файла. Ответ: id|status|base64(body) */
  public void dav(String id, String method, String url, String user, String pass, String b64) {
    new Thread(() -> { try { HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection(); c.setRequestMethod(method); c.setConnectTimeout(8000); c.setReadTimeout(15000);
        c.setRequestProperty("Authorization", "Basic " + Base64.getEncoder().encodeToString((user + ":" + pass).getBytes(StandardCharsets.UTF_8)));
        if (method.equals("PUT")) { c.setDoOutput(true); try (OutputStream o = c.getOutputStream()) { o.write(Base64.getDecoder().decode(b64)); } }
        int st = c.getResponseCode(); InputStream in = st < 400 ? c.getInputStream() : c.getErrorStream(); byte[] body = in == null ? new byte[0] : in.readAllBytes();
        emit("dav", id + "|" + st + "|" + Base64.getEncoder().encodeToString(body));
      } catch (Exception e) { emit("dav", id + "|0|" + Base64.getEncoder().encodeToString(String.valueOf(e.getMessage()).getBytes(StandardCharsets.UTF_8))); } }).start(); }
}
