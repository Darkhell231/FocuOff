package fm;
import android.app.Activity; import android.content.Intent; import android.net.Uri; import android.os.Bundle; import android.view.*; import android.webkit.*; import java.io.File;
public class MainActivity extends Activity {
  WebView wv; NativeCore core; ValueCallback<Uri[]> fcb; boolean locked;
  @Override protected void onCreate(Bundle b) { super.onCreate(b); wv = new WebView(this); setContentView(wv);
    WebSettings s = wv.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
    core = new NativeCore(new File(getFilesDir(), "kv"), sc -> runOnUiThread(() -> wv.evaluateJavascript(sc, null)), on -> runOnUiThread(() -> lock(on)));
    wv.addJavascriptInterface(new Bridge(), "Native"); wv.setWebViewClient(new WebViewClient());
    wv.setWebChromeClient(new WebChromeClient() { @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
      if (fcb != null) fcb.onReceiveValue(null); fcb = cb; startActivityForResult(p.createIntent(), 1); return true; } });
    wv.loadUrl("file:///android_asset/index.html"); }
  @Override protected void onActivityResult(int rq, int rs, Intent d) { if (rq == 1 && fcb != null) { fcb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d)); fcb = null; } }
  @Override protected void onStop() { super.onStop(); core.emit("left", ""); }
  void lock(boolean on) { locked = on;
    if (on) { getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); try { startLockTask(); } catch (Exception e) { }
      getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION); }
    else { getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); try { stopLockTask(); } catch (Exception e) { } getWindow().getDecorView().setSystemUiVisibility(0); } }
  @Override public void onBackPressed() { if (!locked) super.onBackPressed(); }
  public class Bridge {
    @JavascriptInterface public String kvGet(String k) { return core.kvGet(k); }
    @JavascriptInterface public void kvSet(String k, String v) { core.kvSet(k, v); }
    @JavascriptInterface public void host(String n) { core.host(n); }
    @JavascriptInterface public void join(String ip) { core.join(ip); }
    @JavascriptInterface public void discover() { core.discover(); }
    @JavascriptInterface public void send(String l) { core.send(l); }
    @JavascriptInterface public void sendTo(int i, String l) { core.sendTo(i, l); }
    @JavascriptInterface public void sendAll(String l) { core.sendAll(l); }
    @JavascriptInterface public void close() { core.close(); }
    @JavascriptInterface public void lock(boolean on) { core.lock(on); }
    @JavascriptInterface public void dav(String id, String m, String u, String us, String p, String b) { core.dav(id, m, u, us, p, b); }
  }
}
