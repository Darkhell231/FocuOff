package fm;
import javafx.application.*; import javafx.concurrent.Worker; import javafx.scene.Scene; import javafx.scene.input.KeyCombination;
import javafx.scene.web.*; import javafx.stage.Stage; import netscape.javascript.JSObject; import java.io.File;
public class Desktop extends Application {
  static NativeCore keep; Stage st; boolean locked;
  public void start(Stage s) { st = s; WebView wv = new WebView(); WebEngine we = wv.getEngine(); we.setUserAgent("FocumonDesktop");
    NativeCore core = new NativeCore(new File(System.getProperty("user.home"), ".focumon"), sc -> Platform.runLater(() -> we.executeScript(sc)), on -> Platform.runLater(() -> lock(on)));
    keep = core;
    we.getLoadWorker().stateProperty().addListener((o, a, b) -> { if (b == Worker.State.RUNNING || b == Worker.State.SUCCEEDED) ((JSObject) we.executeScript("window")).setMember("Native", core); });
    we.load(getClass().getResource("/index.html").toExternalForm());
    s.focusedProperty().addListener((o, a, f) -> { if (!f) { core.emit("left", ""); if (locked) Platform.runLater(() -> { st.toFront(); st.requestFocus(); }); } });
    s.setTitle("Focumon"); s.setScene(new Scene(wv, 480, 820)); s.show(); }
  void lock(boolean on) { locked = on; st.setAlwaysOnTop(on); st.setFullScreenExitKeyCombination(on ? KeyCombination.NO_MATCH : KeyCombination.keyCombination("Esc")); st.setFullScreen(on); }
}
