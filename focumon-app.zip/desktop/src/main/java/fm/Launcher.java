package fm;
import com.sun.net.httpserver.HttpServer;
import java.io.*; import java.net.*; import java.nio.charset.StandardCharsets; import java.util.*; import java.util.concurrent.*;
/** ПК-оболочка: локальный HTTP-сервер (только 127.0.0.1) + окно Edge/Chrome в режиме --app. */
public class Launcher {
  static final BlockingQueue<String> Q = new LinkedBlockingQueue<>();
  static volatile long last = System.currentTimeMillis(); static volatile int waiting; static volatile boolean seen;
  static final String TOKEN = UUID.randomUUID().toString();
  public static void main(String[] args) throws Exception {
    File dir = new File(System.getProperty("user.home"), ".focumon");
    NativeCore core = new NativeCore(new File(dir, "kv"), Q::add, on -> { });
    HttpServer s = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), 0), 0);
    s.setExecutor(Executors.newCachedThreadPool());
    s.createContext("/", ex -> { try {
        String p = ex.getRequestURI().getPath(); byte[] out; String ct = "text/plain; charset=utf-8";
        if (p.startsWith("/n/")) {
          if (!TOKEN.equals(ex.getRequestHeaders().getFirst("X-T"))) { ex.sendResponseHeaders(403, -1); return; }
          String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
          out = call(core, p.substring(3), body).getBytes(StandardCharsets.UTF_8);
        } else {
          try (InputStream in = Launcher.class.getResourceAsStream(p.equals("/") ? "/index.html" : p)) {
            if (in == null) { ex.sendResponseHeaders(404, -1); return; } out = in.readAllBytes(); }
          if (p.endsWith(".svg")) ct = "image/svg+xml";
          else { ct = "text/html; charset=utf-8"; out = new String(out, StandardCharsets.UTF_8).replace("/*TOKEN*/", TOKEN).getBytes(StandardCharsets.UTF_8); }
        }
        ex.getResponseHeaders().set("Content-Type", ct); ex.sendResponseHeaders(200, out.length); ex.getResponseBody().write(out);
      } catch (Exception e) { } finally { ex.close(); } });
    s.start();
    long start = System.currentTimeMillis();
    open("http://127.0.0.1:" + s.getAddress().getPort() + "/", dir);
    while (true) { Thread.sleep(3000); long now = System.currentTimeMillis();
      if ((seen && waiting == 0 && now - last > 15000) || (!seen && now - start > 60000)) { core.close(); System.exit(0); } }
  }
  static String call(NativeCore c, String m, String body) {
    String[] a = body.split("\u0001", -1);
    switch (m) {
      case "ping": return "ok";
      case "kvGet": return c.kvGet(a[0]);
      case "kvSet": c.kvSet(a[0], a[1]); return "";
      case "host": c.host(a[0]); return "";
      case "join": c.join(a[0]); return "";
      case "discover": c.discover(); return "";
      case "send": c.send(a[0]); return "";
      case "sendTo": c.sendTo(Integer.parseInt(a[0]), a[1]); return "";
      case "sendAll": c.sendAll(a[0]); return "";
      case "close": c.close(); return "";
      case "dav": c.dav(a[0], a[1], a[2], a[3], a[4], a[5]); return "";
      case "events": seen = true; waiting++;
        try { String f = Q.poll(25, TimeUnit.SECONDS); if (f == null) return ""; StringBuilder sb = new StringBuilder(f); String n; while ((n = Q.poll()) != null) sb.append('\n').append(n); return sb.toString(); }
        catch (InterruptedException e) { return ""; } finally { waiting--; last = System.currentTimeMillis(); }
      default: return "";
    } }
  static void open(String url, File dir) throws IOException {
    String pf = System.getenv("ProgramFiles"), px = System.getenv("ProgramFiles(x86)"), la = System.getenv("LOCALAPPDATA");
    String[] c = { px + "\\Microsoft\\Edge\\Application\\msedge.exe", pf + "\\Microsoft\\Edge\\Application\\msedge.exe",
      pf + "\\Google\\Chrome\\Application\\chrome.exe", px + "\\Google\\Chrome\\Application\\chrome.exe", la + "\\Google\\Chrome\\Application\\chrome.exe" };
    for (String p : c) if (new File(p).exists()) {
      new ProcessBuilder(p, "--app=" + url, "--user-data-dir=" + new File(dir, "browser"), "--no-first-run", "--window-size=480,860").start(); return; }
    new ProcessBuilder("rundll32", "url.dll,FileProtocolHandler", url).start();
  }
}
