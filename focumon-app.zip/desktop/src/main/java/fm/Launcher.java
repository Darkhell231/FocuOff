package fm;
public class Launcher { public static void main(String[] a) { javafx.application.Application.launch(Desktop.class, a); } }
